import type { AdoTestPoint } from "../services/adoApi";
import type { AdoTestSuite } from "../types/ado";
import {
    calculateQaMetrics,
    type QaMetrics,
} from "../services/qaAnalytics";

export interface DemoExecution {
    testPointId: number;
    outcome: "passed" | "failed" | "blocked";
    tester: string;
    executedAt: string;
}

export interface DemoRelease {
    id: number;
    name: string;
    suites: AdoTestSuite[];
    points: AdoTestPoint[];
    executions: DemoExecution[];
}

const suiteNames = [
    "AXA Van",
    "AXA BI",
    "AXA Motor",
    "AXA Home",
    "Swiftcover Van",
    "Swiftcover Home",
    "Swiftcover Motor",
    "Moja Motor",
    "Bank of Scotland",
];

function createRelease(
    id: number,
    name: string,
    total: number,
    passed: number,
    failed: number,
    blocked: number,
    notApplicable: number,
    reexecuted: number
): DemoRelease {
    const rootId = id === 819259 ? 838247 : 839719;
    const suiteIds = suiteNames.map((_, index) => id * 100 + index + 1);

    const suites: AdoTestSuite[] = [
        {
            id: rootId,
            name,
            children: [
                {
                    id: id * 100 + 90,
                    name: "Sandpiper_Post-Test",
                    children: [
                        {
                            id: id * 100 + 91,
                            name: "Regression (Manual)",
                            children: suiteNames.map((suiteName, index) => ({
                                id: suiteIds[index],
                                name: suiteName,
                            })),
                        },
                    ],
                },
            ],
        },
    ];

    const points: AdoTestPoint[] = [];
    const executions: DemoExecution[] = [];
    const testers = ["Tester A", "Tester B", "Tester C", "Tester D"];

    for (let index = 0; index < total; index++) {
        const pointId = id * 10000 + index + 1;
        const outcome =
            index < passed
                ? "passed"
                : index < passed + failed
                    ? "failed"
                    : index < passed + failed + blocked
                        ? "blocked"
                        : index < passed + failed + blocked + notApplicable
                            ? "notApplicable"
                            : "unspecified";

        const point: AdoTestPoint = {
            id: pointId,
            testCaseReference: {
                id: 900000 + index,
                name: `Regression Test Case ${index + 1}`,
            },
            results: {
                outcome,
                state: outcome === "unspecified" ? "ready" : "completed",
            },
        };

        points.push(point);

        if (outcome !== "unspecified" && outcome !== "notApplicable") {
            executions.push({
                testPointId: pointId,
                outcome: outcome as DemoExecution["outcome"],
                tester: testers[index % testers.length],
                executedAt: new Date(
                    Date.UTC(2026, 9, 1 + (index % 14))
                ).toISOString(),
            });
        }
    }

    // Add repeat executions to distinct points within this release.
    for (let index = 0; index < reexecuted; index++) {
        const original = executions[index];

        if (!original) break;

        executions.push({
            ...original,
            executedAt: new Date(
                Date.UTC(2026, 9, 15, index % 24)
            ).toISOString(),
        });
    }

    return { id, name, suites, points, executions };
}

export const demoReleases: DemoRelease[] = [
    createRelease(
        819259,
        "Frontier AI",
        889,
        504,
        0,
        2,
        14,
        48
    ),
    createRelease(
        839718,
        "Frontier AI - R2",
        620,
        410,
        18,
        7,
        5,
        36
    ),
];

export function getDemoRelease(
    releaseId: number
): DemoRelease {
    return (
        demoReleases.find((release) => release.id === releaseId) ??
        demoReleases[0]
    );
}

export function getDemoMetrics(
    releaseId: number
): QaMetrics {
    return calculateQaMetrics(getDemoRelease(releaseId).points);
}

export function getDemoReexecutionCount(
    releaseId: number
): number {
    const executions = getDemoRelease(releaseId).executions;
    const counts = new Map<number, number>();

    for (const execution of executions) {
        counts.set(
            execution.testPointId,
            (counts.get(execution.testPointId) ?? 0) + 1
        );
    }

    return [...counts.values()].filter((count) => count > 1).length;
}

export function getDemoTesterProductivity(releaseId: number) {
    const executions = getDemoRelease(releaseId).executions;
    const counts = new Map<string, number>();

    for (const execution of executions) {
        counts.set(
            execution.tester,
            (counts.get(execution.tester) ?? 0) + 1
        );
    }

    return [...counts.entries()].map(([tester, executions]) => ({
        tester,
        executions,
    }));
}