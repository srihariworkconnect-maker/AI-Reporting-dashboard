
import * as SDK from "azure-devops-extension-sdk";

let initializationPromise: Promise<boolean> | null = null;

export function initializeAdoExtension(): Promise<boolean> {
    if (window.self === window.top) {
        return Promise.resolve(false);
    }

    if (initializationPromise) {
        return initializationPromise;
    }

    initializationPromise = (async () => {
        try {
            SDK.init({
                loaded: false,
                applyTheme: true,
            });

            await SDK.ready();

            SDK.register(SDK.getContributionId(), () => ({
                load: async () => {
                    
                    return {
                        state: 0,
                    };
                },
            }));

            SDK.notifyLoadSucceeded();

            console.log("Sandpiper QA widget initialized");
            return true;
        } catch (error) {
            console.error("ADO widget initialization failed:", error);
            return false;
        }
    })();

    return initializationPromise;
}