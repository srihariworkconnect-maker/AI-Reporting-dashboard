export interface AdoTestSuite {
    id: number;
    name: string;
    suiteType?: string;
    children?: AdoTestSuite[];
}

export interface AdoTestSuiteResponse {
    value: AdoTestSuite[];
    count: number;
}