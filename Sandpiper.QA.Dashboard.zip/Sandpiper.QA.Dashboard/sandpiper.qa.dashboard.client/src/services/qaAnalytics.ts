import type { AdoTestSuite } from '../types/ado';
import type { AdoTestPoint } from './adoApi';
import { getTestPoints } from './adoApi';

export async function loadPlanMetrics(
    planId: number,
    suites: AdoTestSuite[]
): Promise<QaMetrics> {
    const suiteIds = getAllSuiteIds(suites);
    const allPoints: AdoTestPoint[] = [];

    // Process in small batches to avoid excessive API requests.
    const batchSize = 5;

    for (let i = 0; i < suiteIds.length; i += batchSize) {
        const batch = suiteIds.slice(i, i + batchSize);

        const results = await Promise.all(
            batch.map(suiteId => getTestPoints(planId, suiteId))
        );

        for (const points of results) {
            allPoints.push(...points);
        }
    }

    return calculateQaMetrics(allPoints);
}

export interface QaMetrics {
    total: number;
    passed: number;
    failed: number;
    blocked: number;
    pending: number;
    notApplicable: number;
    executed: number;
    executionRate: number;
    passRate: number;
}

export function getAllSuiteIds(
    suites: AdoTestSuite[]
): number[] {
    const ids = new Set<number>();

    function visit(suite: AdoTestSuite) {
        ids.add(suite.id);

        for (const child of suite.children ?? []) {
            visit(child);
        }
    }

    suites.forEach(visit);

    return [...ids];
}

export function calculateQaMetrics(
    points: AdoTestPoint[]
): QaMetrics {
    const uniquePoints = new Map<number, AdoTestPoint>();

    for (const point of points) {
        uniquePoints.set(point.id, point);
    }

    const metrics: QaMetrics = {
        total: uniquePoints.size,
        passed: 0,
        failed: 0,
        blocked: 0,
        pending: 0,
        notApplicable: 0,
        executed: 0,
        executionRate: 0,
        passRate: 0
    };

    for (const point of uniquePoints.values()) {
        const outcome =
            point.results?.outcome?.toLowerCase() ?? '';

        switch (outcome) {
            case 'passed':
                metrics.passed++;
                break;

            case 'failed':
                metrics.failed++;
                break;

            case 'blocked':
                metrics.blocked++;
                break;

            case 'notapplicable':
                metrics.notApplicable++;
                break;

            default:
                metrics.pending++;
                break;
        }
    }

    metrics.executed =
        metrics.passed +
        metrics.failed +
        metrics.blocked +
        metrics.notApplicable;

    metrics.executionRate = metrics.total > 0
        ? (metrics.executed / metrics.total) * 100
        : 0;

    metrics.passRate = metrics.executed > 0
        ? (metrics.passed / metrics.executed) * 100
        : 0;

    return metrics;
}