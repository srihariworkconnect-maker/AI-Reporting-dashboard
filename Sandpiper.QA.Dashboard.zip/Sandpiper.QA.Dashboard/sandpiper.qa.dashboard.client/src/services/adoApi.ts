import * as SDK from 'azure-devops-extension-sdk';
import type { AdoTestSuiteResponse } from '../types/ado';

const ORGANIZATION = 'axaiuk-axaazureforge';
const PROJECT = 'Sandpiper';


export interface AdoTestPlan {
    id: number;
    name: string;
}

interface AdoTestPlansResponse {
    value: AdoTestPlan[];
    count: number;
}

export async function getTestPlans(): Promise<AdoTestPlan[]> {
    await SDK.ready();

    const accessToken = await SDK.getAccessToken();

    const response = await fetch(
        `https://dev.azure.com/${ORGANIZATION}/${PROJECT}` +
        '/_apis/testplan/plans?api-version=7.1',
        {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                Accept: 'application/json'
            }
        }
    );

    if (!response.ok) {
        throw new Error(
            `Failed to retrieve test plans: ${response.status}`
        );
    }

    const data =
        (await response.json()) as AdoTestPlansResponse;

    return data.value;
}

export async function getTestSuites(
    planId: number
): Promise<AdoTestSuiteResponse> {
    await SDK.ready();

    const accessToken = await SDK.getAccessToken();

    const response = await fetch(
        `https://dev.azure.com/${ORGANIZATION}/${PROJECT}` +
        `/_apis/testplan/Plans/${planId}/suites` +
        '?asTreeView=true&api-version=7.1',
        {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                Accept: 'application/json'
            }
        }
    );

    if (!response.ok) {
        throw new Error(
            `Failed to retrieve test suites: ${response.status}`
        );
    }

    return (await response.json()) as AdoTestSuiteResponse;
}


export interface AdoTestPoint {
    id: number;

    testCaseReference?: {
        id: number;
        name: string;
    };

    configuration?: {
        id: number;
        name: string;
    };

    results?: {
        outcome?: string;
        state?: string;
        lastResultId?: number;
        lastResultDetails?: {
            dateCompleted?: string;
            duration?: number;
            runBy?: {
                displayName?: string;
            };
        };
    };
}


    interface AdoTestPointsResponse {
        value: AdoTestPoint[];
        count: number;
    }

    export async function getTestPoints(
        planId: number,
        suiteId: number
    ): Promise<AdoTestPoint[]> {
        await SDK.ready();

        const accessToken = await SDK.getAccessToken();

        const allPoints: AdoTestPoint[] = [];
        let continuationToken: string | null = null;

        do {
            const url = new URL(
                `https://dev.azure.com/${ORGANIZATION}/${PROJECT}` +
                `/_apis/testplan/Plans/${planId}` +
                `/Suites/${suiteId}/TestPoint`
            );

            url.searchParams.set('api-version', '7.1');

            if (continuationToken) {
                url.searchParams.set('continuationToken', continuationToken);
            }

            const response = await fetch(url.toString(), {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    Accept: 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(
                    `Failed to retrieve test points: ${response.status}`
                );
            }

            const data =
                (await response.json()) as AdoTestPointsResponse;

            allPoints.push(...data.value);

            continuationToken =
                response.headers.get('x-ms-continuationtoken');
        } while (continuationToken);

        return allPoints;
    }
