﻿
import { useEffect, useState } from 'react';
import './App.css';
import TestSuiteTree from './components/TestSuiteTree';
import type { AdoTestSuite } from './types/ado';
import {
        getTestPlans,
    type AdoTestPlan
} from './services/adoApi';

import {  type QaMetrics } from './services/qaAnalytics'
import {
    demoReleases,
    getDemoRelease,
    getDemoMetrics,
} from "./data/demoData"

type TestStatus = {
    total: number;
    passed: number;
    failed: number;
    blocked: number;
    pending: number;
    notApplicable: number;
    reExecuted: number | null;
};

const status: TestStatus = {
    total: 889,
    passed: 504,
    failed: 0,
    blocked: 2,
    pending: 369,
    notApplicable: 14,
    reExecuted: null
};



function App() {

    const [release, setRelease] = useState(819259);

    const [testPlans, setTestPlans] = useState<AdoTestPlan[]>(
        demoReleases.map(({ id, name }) => ({ id, name }))
    );

    const [suiteTree, setSuiteTree] =
        useState<AdoTestSuite[]>(getDemoRelease(819259).suites);

    const [suiteDataSource, setSuiteDataSource] =
        useState('Preview hierarchy');

    const [liveMetrics, setLiveMetrics] = useState<QaMetrics | null>(null);

    const [isLoadingSuites, setIsLoadingSuites] =
        useState(false);

    function buildSuiteTree(
        suites: {
            suiteId: number;
            suiteName: string;
            parentSuiteId: number | null;
        }[]


    ): AdoTestSuite[] {
        const nodes = new Map<number, AdoTestSuite>();
        const roots: AdoTestSuite[] = [];

        for (const suite of suites) {
            nodes.set(suite.suiteId, {
                id: suite.suiteId,
                name: suite.suiteName,
                children: [],
            });
        }


        for (const suite of suites) {
            const node = nodes.get(suite.suiteId)!;
            const parent = suite.parentSuiteId == null
                ? undefined
                : nodes.get(suite.parentSuiteId);

            if (parent) {
                parent.children!.push(node);
            } else {
                roots.push(node);
            }
        }

        return roots;
    }
    async function fetchLiveAnalytics(planId: number) {
        const response = await fetch(
            `https://localhost:7167/api/ado/frontier/analytics/${planId}`
        );

        if (!response.ok) {
            throw new Error(
                `ADO analytics request failed: ${response.status}`
            );
        }

        return response.json();
    }

    useEffect(() => {
        let active = true;

        async function loadLiveAnalytics() {
            try {
                const data = await fetchLiveAnalytics(release);

                if (active) {
                    setSuiteTree(buildSuiteTree(data.suites))
                    setLiveMetrics({
                        total: data.total,
                        passed: data.passed,
                        failed: data.failed,
                        blocked: data.blocked,
                        pending: data.pending,
                        notApplicable: data.other,
                        executed: data.total - data.pending,
                        executionRate: data.executionPercentage,
                        passRate: data.passPercentage,
                    });

                    console.log("Live ADO analytics:", data);
                }
            } catch (error) {
                console.error("Failed to load live ADO analytics:", error);
            }
        }

        void loadLiveAnalytics();

        return () => {
            active = false;
        };
    }, [release]);

   

    useEffect(() => {
        let active = true;


        async function loadSuites() {
            

            setIsLoadingSuites(true);

            try {
                const plans = await getTestPlans();
                if (active) {
                    setTestPlans(plans);
                }

                if (!active) return;


                if (!active) return;
                              

            } catch (error) {
                console.error('Failed to load ADO test suites:', error);

                if (active) {
                    setSuiteDataSource('Preview hierarchy - API unavailable');
                }
            } finally {
                if (active) {
                    setIsLoadingSuites(false);
                }
            }
        }

       
        void loadSuites();

        return () => {
            active = false;
        };
    }, [release]);

    const displayStatus = liveMetrics ??
        getDemoMetrics(release);

    const executed =
        displayStatus.passed +
        displayStatus.failed +
        displayStatus.blocked +
        displayStatus.notApplicable;

    const executionRate =
        displayStatus.total > 0
            ? (executed / displayStatus.total) * 100
            : 0;

    const passRate =
        executed > 0
            ? (displayStatus.passed / executed) * 100
            : 0;

    

    const metrics = [
        {
            label: 'Total Test Points',
            value: displayStatus.total,
            tone: 'blue'
        },
        {
            label: 'Passed',
            value: displayStatus.passed,
            tone: 'green'
        },
        {
            label: 'Failed',
            value: displayStatus.failed,
            tone: 'red'
        },
        {
            label: 'Blocked',
            value: displayStatus.blocked,
            tone: 'orange'
        },
        {
            label: 'Pending',
            value: displayStatus.pending,
            tone: 'gray'
        },
        {
            label: 'Re-executed',
            value: '-',
            tone: 'purple'
        }
    ];

    return (
        <div className="dashboard">
            <aside className="sidebar">
                <div className="brand">
                    <div className="brand-icon">S</div>
                    <div>
                        <strong>Sandpiper</strong>
                        <span>QA Intelligence</span>
                    </div>
                </div>

                <div className="nav-heading">WORKSPACE</div>
                <div className="nav-item active">◫ &nbsp; Overview</div>
                <div className="nav-item">▦ &nbsp; Test Suites</div>
                <div className="nav-item">↻ &nbsp; Re-execution</div>
                <div className="nav-item">▤ &nbsp; Execution Trends</div>
                <div className="nav-item">◇ &nbsp; Release Readiness</div>

                <div className="sidebar-footer">
                    Sandpiper QA Command Center
                    <span>Version 0.1 · Local preview</span>
                </div>
            </aside>

            <main className="main">
                <header className="topbar">
                    <div>
                        <div className="eyebrow">QUALITY ENGINEERING / OVERVIEW</div>
                        <h1>QA Command Center</h1>
                        <p>Release quality, test execution and engineering insights.</p>
                    </div>

                    <div className="toolbar">
                        <label htmlFor="release">Test Plan</label>
                        <select
                            id="release"
                            value={release}
                            onChange={(event) => setRelease(Number(event.target.value))}
                        >
                            {testPlans.map((plan) => (
                                <option key={plan.id} value={plan.id}>
                                    {plan.name}
                                </option>
                            ))}
                        </select>
                        <span className="preview-tag">
                            {liveMetrics ? 'Live ADO Data' : 'Preview Data'}
                        </span>
                    </div>
                </header>

                <section className="section">
                    <div className="section-title">
                        <h2>Execution overview</h2>
                        <span>Plan ID: 819259</span>
                    </div>

                    <div className="kpi-grid">
                        {metrics.map((metric) => (
                            <article className={`kpi-card ${metric.tone}`} key={metric.label}>
                                <div className="kpi-label">{metric.label}</div>
                                <div className="kpi-value">{metric.value}</div>
                                <div className="kpi-caption">
                                    {metric.label === 'Re-executed'
                                        ? 'Awaiting execution history'
                                        : 'Latest observed report'}
                                </div>
                            </article>
                        ))}
                    </div>
                </section>

                <section className="insights-grid">
                    <article className="panel">
                        <div className="panel-header">
                            <h2>Execution progress</h2>
                            <span>All test points</span>
                        </div>

                        <div className="progress-number">
                            {executionRate.toFixed(1)}%
                            <span> executed</span>
                        </div>

                        <div className="progress-track">
                            <div
                                className="progress-fill"
                                style={{ width: `${executionRate}%` }}
                            />
                        </div>

                        <div className="stat-row">
                            <span>Executed</span>
                            <strong>{executed}</strong>
                        </div>
                        <div className="stat-row">
                            <span>Pending</span>
                            <strong>{status.pending}</strong>
                        </div>
                        <div className="stat-row">
                            <span>Not applicable</span>
                            <strong>{status.notApplicable}</strong>
                        </div>
                    </article>

                    <article className="panel">
                        <div className="panel-header">
                            <h2>Quality indicators</h2>
                            <span>Latest outcomes</span>
                        </div>

                        <div className="quality-score">
                            {passRate.toFixed(1)}%
                            <span> pass rate of executed points</span>
                        </div>

                        <div className="stat-row">
                            <span>Failed test points</span>
                            <strong>{status.failed}</strong>
                        </div>
                        <div className="stat-row">
                            <span>Blocked test points</span>
                            <strong>{status.blocked}</strong>
                        </div>
                        <div className="stat-row">
                            <span>Re-executed points</span>
                            <strong>Not yet available</strong>
                        </div>

                        <p className="panel-note">
                            Re-execution counts distinct test points with more than
                            one execution within the selected release.
                        </p>
                    </article>
                </section>

                <section className="panel suite-panel">
                    <div className="panel-header">
                        <div>
                            <h2>Test Suite Explorer</h2>
                            <p>Frontier AI test plan hierarchy</p>
                        </div>
                        <span>
                            {isLoadingSuites ? 'Loading Azure DevOps suites...' : suiteDataSource}
                        </span>
                    </div>

                    <TestSuiteTree suites={suiteTree} />
                </section>

                <footer className="dashboard-footer">
                    Data source: Previous Azure DevOps report snapshot ·
                    Live API connection not configured
                </footer>
            </main>
        </div>
    );
}

export default App;
