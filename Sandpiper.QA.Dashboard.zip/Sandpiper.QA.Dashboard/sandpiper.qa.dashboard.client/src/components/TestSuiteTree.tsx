import { useState } from 'react';
import type { AdoTestSuite } from '../types/ado';

interface TestSuiteTreeProps {
    suites: AdoTestSuite[];
}

export default function TestSuiteTree({
    suites
}: TestSuiteTreeProps) {
    const [expanded, setExpanded] = useState<Set<number>>(
        () => new Set()
    );

    function toggleSuite(id: number) {
        setExpanded(previous => {
            const next = new Set(previous);

            if (next.has(id)) {
                next.delete(id);
            } else {
                next.add(id);
            }

            return next;
        });
    }

    function renderSuite(
        suite: AdoTestSuite,
        depth: number
    ): React.ReactNode {
        const children = suite.children ?? [];
        const hasChildren = children.length > 0;
        const isExpanded = expanded.has(suite.id);

        return (
            <div key={suite.id}>
                <div
                    style={{
                        padding: '12px 14px',
                        paddingLeft: `${14 + depth * 24}px`,
                        borderBottom: '1px solid #edf1f6',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px'
                    }}
                >
                    {hasChildren ? (
                        <button
                            type="button"
                            onClick={() => toggleSuite(suite.id)}
                            aria-expanded={isExpanded}
                            aria-label={`${isExpanded ? 'Collapse' : 'Expand'} ${suite.name}`}
                            style={{
                                cursor: 'pointer',
                                border: 'none',
                                background: 'transparent',
                                fontSize: '14px'
                            }}
                        >
                            {isExpanded ? '▼' : '▶'}
                        </button>
                    ) : (
                        <span style={{ width: '22px' }}>•</span>
                    )}

                    <span>{suite.name}</span>
                </div>

                {hasChildren && isExpanded &&
                    children.map(child => renderSuite(child, depth + 1))}
            </div>
        );
    }

    return (
        <div>
            {suites.map(suite => renderSuite(suite, 0))}
        </div>
    );
}