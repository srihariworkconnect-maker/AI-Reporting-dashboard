using Azure.Core;
using Azure.Identity;

using Sandpiper.QA.Dashboard.Server.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient<FrontierAnalyticsService>();
builder.Services.AddHttpClient();

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();


builder.Services.AddCors(options =>
{
    options.AddPolicy("DashboardClient", policy =>
    {
        policy.WithOrigins("https://localhost:64423")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

app.UseCors("DashboardClient");

app.UseDefaultFiles();
app.MapStaticAssets();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapGet(
    "/api/ado/frontier/analytics/{planId:int}",
    async (int planId, FrontierAnalyticsService analytics) =>
    {
        if (planId != 819259 && planId != 839718)
            return Results.BadRequest(new
            {
                error = "Unsupported test plan"
            });

        try
        {
            var result = await analytics.GetAnalyticsAsync(planId);
            return Results.Ok(result);
        }
        catch (Exception ex)
        {
            app.Logger.LogError(
                ex,
                "Failed to retrieve Frontier analytics for plan {PlanId}",
                planId);

            return Results.Problem(
                "Unable to retrieve live Azure DevOps analytics.",
                statusCode: 502);
        }
    });
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.MapFallbackToFile("/index.html");

if (app.Environment.IsDevelopment())
{
    app.MapGet("/api/auth/check", async () =>
    {
        try
        {
            var credential = new Azure.Identity.DefaultAzureCredential(
    new Azure.Identity.DefaultAzureCredentialOptions
    {
        TenantId = "99e52f80-9cba-497b-b574-b25e2d8a134d",
        ExcludeInteractiveBrowserCredential = true
    });

            var token = await credential.GetTokenAsync(
                new TokenRequestContext(
                    new[] {
                        "499b84ac-1321-427f-aa17-267ca6975798/.default"
                    }));

            return Results.Ok(new
            {
                authenticated = true,
                expiresOn = token.ExpiresOn
            });
        }
        catch (CredentialUnavailableException)
        {
            return Results.Ok(new
            {
                authenticated = false,
                reason = "No supported organizational credential available"
            });
        }
        catch (AuthenticationFailedException)
        {
            return Results.Ok(new
            {
                authenticated = false,
                reason = "Organizational authentication failed"
            });
        }
    });
}

if (app.Environment.IsDevelopment())
{
    app.MapGet("/api/ado/testplans", async (IHttpClientFactory factory) =>
    {
        try
        {
            var credential = new Azure.Identity.VisualStudioCredential(
    new Azure.Identity.VisualStudioCredentialOptions
    {
        TenantId = "99e52f80-9cba-497b-b574-b25e2d8a134d"
    });

            var token = await credential.GetTokenAsync(
    new Azure.Core.TokenRequestContext(new[]
    {
        "499b84ac-1321-427f-aa17-267ca6975798/.default"
    }),
    System.Threading.CancellationToken.None);

            var tokenParts = token.Token.Split('.');
            var payload = tokenParts[1]
                .Replace('-', '+')
                .Replace('_', '/');

            payload = payload.PadRight(
                payload.Length + (4 - payload.Length % 4) % 4, '=');

            using var tokenJson = System.Text.Json.JsonDocument.Parse(
                Convert.FromBase64String(payload));

            var claims = tokenJson.RootElement;

            string? GetClaim(string name) =>
                claims.TryGetProperty(name, out var value)
                    ? value.ToString()
                    : null;

            Console.WriteLine($"Token audience: {GetClaim("aud")}");
            Console.WriteLine($"Token tenant: {GetClaim("tid")}");
            Console.WriteLine($"Token type: {(GetClaim("scp") != null ? "Delegated user" : "Application or other")}");

            var tokenTenant = tokenJson.RootElement
                .GetProperty("tid").GetString();

            Console.WriteLine($"ADO token tenant: {tokenTenant}");

            using var client = factory.CreateClient();

            using var request = new HttpRequestMessage(
                HttpMethod.Get,
                "https://dev.azure.com/axaiuk-axaazureforge/Sandpiper/" +
                "_apis/testplan/plans?api-version=7.1");

            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue(
                    "Bearer", token.Token);

            using var response = await client.SendAsync(request);

            Console.WriteLine(
                $"ADO status: {(int)response.StatusCode}");

            Console.WriteLine(
                $"ADO authentication challenge: {response.Headers.WwwAuthenticate}");


            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                return Results.Json(new
                {
                    connected = false,
                    statusCode = (int)response.StatusCode,

                    tokenAudience = GetClaim("aud"),
                    tokenTenant = GetClaim("tid"),
                    tokenType = GetClaim("scp") != null
                        ? "Delegated user"
                        : "Application or other",

                    authenticationChallenge =
                        response.Headers.WwwAuthenticate.ToString()
                });
            }

            return Results.Content(content, "application/json");
        }
        catch (Exception ex)
        {
            return Results.Json(new
            {
                connected = false,
                errorType = ex.GetType().Name
            });
        }
    });
}

if (app.Environment.IsDevelopment())
{
    app.MapGet("/api/ado/frontier/suites/{planId:int}",
        async (int planId, IHttpClientFactory factory) =>
        {
            try
            {
                var credential = new Azure.Identity.VisualStudioCredential(
                    new Azure.Identity.VisualStudioCredentialOptions
                    {
                        TenantId = "99e52f80-9cba-497b-b574-b25e2d8a134d"
                    });

                var token = await credential.GetTokenAsync(
                    new Azure.Core.TokenRequestContext(new[]
                    {
                    "499b84ac-1321-427f-aa17-267ca6975798/.default"
                    }),
                    System.Threading.CancellationToken.None);

                using var client = factory.CreateClient();

                using var request = new HttpRequestMessage(
                    HttpMethod.Get,
                    "https://dev.azure.com/axaiuk-axaazureforge/Sandpiper/" +
                    $"_apis/testplan/Plans/{planId}/suites" +
                    "?asTreeView=true&api-version=7.1");

                request.Headers.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "Bearer", token.Token);

                using var response = await client.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    return Results.Json(new
                    {
                        connected = false,
                        statusCode = (int)response.StatusCode
                    });
                }

                var json = await response.Content.ReadAsStringAsync();

                return Results.Content(json, "application/json");
            }
            catch (Exception ex)
            {
                return Results.Json(new
                {
                    connected = false,
                    errorType = ex.GetType().Name
                });
            }
        });
}

if (app.Environment.IsDevelopment())
{
    app.MapGet("/api/ado/frontier/points/{planId:int}/{suiteId:int}",
        async (int planId, int suiteId, IHttpClientFactory factory) =>
        {
            if (planId != 819259 && planId != 839718)
                return Results.BadRequest("Unsupported test plan.");

            try
            {
                var credential = new Azure.Identity.VisualStudioCredential(
                    new Azure.Identity.VisualStudioCredentialOptions
                    {
                        TenantId = "99e52f80-9cba-497b-b574-b25e2d8a134d"
                    });

                var token = await credential.GetTokenAsync(
                    new Azure.Core.TokenRequestContext(new[]
                    {
                    "499b84ac-1321-427f-aa17-267ca6975798/.default"
                    }),
                    System.Threading.CancellationToken.None);

                using var client = factory.CreateClient();

                var url =
    "https://dev.azure.com/axaiuk-axaazureforge/Sandpiper/" +
    $"_apis/testplan/Plans/{planId}/Suites/{suiteId}/TestPoint" +
    "?api-version=7.1";

                using var request =
                    new HttpRequestMessage(HttpMethod.Get, url);

                request.Headers.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "Bearer", token.Token);

                using var response = await client.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                    return Results.Json(new
                    {
                        connected = false,
                        statusCode = (int)response.StatusCode
                    });

                var json = await response.Content.ReadAsStringAsync();

                return Results.Content(json, "application/json");
            }
            catch (Exception ex)
            {
                return Results.Json(new
                {
                    connected = false,
                    errorType = ex.GetType().Name
                });
            }
        });
}

app.Run();
