﻿namespace Sandpiper.QA.Dashboard.Server.Services
{
    public class AzureDevOpsService
    {
        private readonly HttpClient _httpClient;

        public AzureDevOpsService(HttpClient
            httpClient)
        {
            _httpClient = httpClient;
        }
        private const string Organization = "axaiuk-axaazureforge";
        private const string Project = "Sandpiper";
        private const int TestPlanId = 819259;

        public string GetTestSuitesApiUrl()
        {
            return $"https://dev.azure.com/{Organization}/{Project}" +
                   $"/_apis/testplan/Plans/{TestPlanId}/suites" +
                   "?asTreeView=true&api-version=7.1";
        }

        public string GetTestPointsApiUrl(int suiteId)
        {
            return $"https://dev.azure.com/{Organization}/{Project}" +
                   $"/_apis/testplan/Plans/{TestPlanId}" +
                   $"/Suites/{suiteId}/TestPoint?api-version=7.1";
        }
    }
}