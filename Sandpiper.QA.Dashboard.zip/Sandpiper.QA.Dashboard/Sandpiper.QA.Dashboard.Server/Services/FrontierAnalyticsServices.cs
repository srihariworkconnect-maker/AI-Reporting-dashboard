﻿using System.Net.Http.Headers;
using System.Text.Json;
using Azure.Core;
using Azure.Identity;

namespace Sandpiper.QA.Dashboard.Server.Services;

public class FrontierAnalyticsService
{
    private readonly HttpClient _client;

    private const string BaseUrl =
        "https://dev.azure.com/axaiuk-axaazureforge/Sandpiper";

    private const string TenantId =
        "99e52f80-9cba-497b-b574-b25e2d8a134d";

    private const string Scope =
        "499b84ac-1321-427f-aa17-267ca6975798/.default";

    public FrontierAnalyticsService(HttpClient client)
    {
        _client = client;
    }

    public async Task<object> GetAnalyticsAsync(int planId)
    {
        if (planId != 819259 && planId != 839718)
            throw new ArgumentException("Unsupported test plan.");

        var credential = new VisualStudioCredential(
            new VisualStudioCredentialOptions
            {
                TenantId = TenantId
            });

        var token = await credential.GetTokenAsync(
            new TokenRequestContext(new[] { Scope }),
            CancellationToken.None);

        var suitesUrl =
            $"{BaseUrl}/_apis/testplan/Plans/{planId}/suites" +
            "?asTreeView=true&api-version=7.1";

        using var suitesJson =
            await GetJsonAsync(suitesUrl, token.Token);

        var suites = new List<SuiteInfo>();
        var visited = new HashSet<int>();

        var root = suitesJson.RootElement;

        if (root.TryGetProperty("value", out var values))
        {
            foreach (var suite in values.EnumerateArray())
                CollectSuites(suite, suites, visited);
        }
        else
        {
            CollectSuites(root, suites, visited);
        }

        var results = new List<object>();

        int total = 0;
        int passed = 0;
        int failed = 0;
        int blocked = 0;
        int pending = 0;
        int other = 0;

        foreach (var suite in suites)
        {
            var suitePoints = new List<JsonElement>();
            var continuationToken = "";

            do
            {
                var pointsUrl =
                    $"{BaseUrl}/_apis/testplan/Plans/{planId}" +
                    $"/Suites/{suite.Id}/TestPoint?api-version=7.1";

                using var request = new HttpRequestMessage(
                    HttpMethod.Get, pointsUrl);

                request.Headers.Authorization =
                    new AuthenticationHeaderValue(
                        "Bearer", token.Token);

                if (!string.IsNullOrEmpty(continuationToken))
                    request.Headers.TryAddWithoutValidation(
                        "x-ms-continuationtoken",
                        continuationToken);

                using var response =
                    await _client.SendAsync(request);

                response.EnsureSuccessStatusCode();

                using var document = JsonDocument.Parse(
                    await response.Content.ReadAsStringAsync());

                if (document.RootElement.TryGetProperty(
                    "value", out var points))
                {
                    foreach (var point in points.EnumerateArray())
                        suitePoints.Add(point.Clone());
                }

                continuationToken =
                    response.Headers.TryGetValues(
                        "x-ms-continuationtoken", out var headers)
                        ? headers.FirstOrDefault() ?? ""
                        : "";

            } while (!string.IsNullOrEmpty(continuationToken));

            int suitePassed = 0;
            int suiteFailed = 0;
            int suiteBlocked = 0;
            int suitePending = 0;
            int suiteOther = 0;

            foreach (var point in suitePoints)
            {
                var outcome = "";

                if (point.TryGetProperty("results", out var pointResults)
                    && pointResults.ValueKind == JsonValueKind.Object
                    && pointResults.TryGetProperty("outcome", out var value)
                    && value.ValueKind == JsonValueKind.String)
                {
                    outcome = value.GetString() ?? "";
                }

                switch (outcome.ToLowerInvariant())
                {
                    case "passed":
                        suitePassed++;
                        break;
                    case "failed":
                        suiteFailed++;
                        break;
                    case "blocked":
                        suiteBlocked++;
                        break;
                    case "active":
                    case "notexecuted":
                    case "unspecified":
                        suitePending++;
                        break;
                    default:
                        suiteOther++;
                        break;
                }
            }

            total += suitePoints.Count;
            passed += suitePassed;
            failed += suiteFailed;
            blocked += suiteBlocked;
            pending += suitePending;
            other += suiteOther;

            results.Add(new
            {
                suiteId = suite.Id,
                suiteName = suite.Name,
                parentSuiteId = suite.ParentId,
                total = suitePoints.Count,
                passed = suitePassed,
                failed = suiteFailed,
                blocked = suiteBlocked,
                pending = suitePending,
                other = suiteOther
            });
        }

        return new
        {
            connected = true,
            planId,
            suiteCount = suites.Count,
            total,
            passed,
            failed,
            blocked,
            pending,
            other,
            executionPercentage = total == 0
                ? 0
                : Math.Round(
                    (double)(total - pending) / total * 100, 2),
            passPercentage = passed + failed + blocked == 0
                ? 0
                : Math.Round(
                    (double)passed /
                    (passed + failed + blocked) * 100, 2),
            suites = results
        };
    }

    private async Task<JsonDocument> GetJsonAsync(
        string url, string accessToken)
    {
        using var request =
            new HttpRequestMessage(HttpMethod.Get, url);

        request.Headers.Authorization =
            new AuthenticationHeaderValue(
                "Bearer", accessToken);

        using var response = await _client.SendAsync(request);
        response.EnsureSuccessStatusCode();

        return JsonDocument.Parse(
            await response.Content.ReadAsStringAsync());
    }

    private static void CollectSuites(
        JsonElement element,
        List<SuiteInfo> suites,
        HashSet<int> visited,
        int? parentId = null)
    {
        if (element.ValueKind != JsonValueKind.Object)
            return;

        int? currentId = parentId;

        if (element.TryGetProperty("id", out var idElement)
            && idElement.TryGetInt32(out var id))
        {
            currentId = id;

            if (visited.Add(id))
            {
                var name = element.TryGetProperty(
                    "name", out var nameElement)
                    ? nameElement.GetString() ?? ""
                    : "";

                suites.Add(new SuiteInfo(id, name, parentId));
            }
        }

        if (element.TryGetProperty(
            "children", out var children)
            && children.ValueKind == JsonValueKind.Array)
        {
            foreach (var child in children.EnumerateArray())
                CollectSuites(
                    child, suites, visited, currentId);
        }
    }

    private record SuiteInfo(
        int Id,
        string Name,
        int? ParentId);
}